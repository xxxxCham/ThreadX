"""
ThreadX Token Management Module
================================

Module unifié pour la gestion complète des tokens crypto dans ThreadX.

Consolide:
- Token selection (top 100 by market cap, volume, diversity)
- Token validation (Binance USDC pairs)
- Diversity provider (OHLCV data with groups: L1, DeFi, L2, etc.)
- Cache management

API Publique:
-------------
Classes:
  - TokenManager: Gestion top tokens (market cap + volume + validation)
  - TokenDiversityConfig: Configuration groupes & symboles pour diversity
  - TokenDiversityDataSource: Provider OHLCV pour analyse de diversité

Fonctions:
  - get_top100_tokens(): Helper pour récupérer top 100 USDC tokens
  - create_default_config(): Config par défaut pour diversity (groupes L1/DeFi/L2/Stable)

Usage:
------
    # Top tokens
    from threadx.data.tokens import TokenManager
    manager = TokenManager()
    top_tokens = manager.get_top_tokens(limit=100, usdc_only=True)

    # Diversity provider
    from threadx.data.tokens import TokenDiversityDataSource, create_default_config
    config = create_default_config()
    provider = TokenDiversityDataSource(config)
    symbols = provider.list_symbols("L1")  # BTC, ETH, SOL, ADA...
    ohlcv_df = provider.fetch_ohlcv("BTCUSDC", "1h")
"""

from __future__ import annotations

import logging
from typing import List, Dict, Optional, Set, Mapping, Tuple, Any
from pathlib import Path
from dataclasses import dataclass
from datetime import datetime
import json

import requests
import pandas as pd

__all__ = list(globals().get("__all__", []))

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class IndicatorSpec:
    """Specification for an indicator used in tests."""

    name: str
    params: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class PriceSourceSpec:
    """Specification for a price source used by TokenDiversityManager tests."""

    name: str
    params: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class RunMetadata:
    """Small structure returned by prepare_dataframe / run methods in tests."""

    market: Optional[str] = None
    timeframe: Optional[str] = None
    execution_time_ms: Optional[float] = None


# preserve any existing exports if defined later
__all__ = list(globals().get("__all__", []))

__all__ = [
    # TokenManager (top tokens selection)
    "TokenManager",
    "get_top100_tokens",
    # Diversity provider
    "TokenDiversityConfig",
    "TokenDiversityDataSource",
    "create_default_config",
    # small test compatibility symbols
    "IndicatorSpec",
    "PriceSourceSpec",
    "RunMetadata",
]


class TokenManager:
    """Gestionnaire unifié pour la sélection et validation des tokens."""

    def __init__(self, cache_path: Optional[Path] = None):
        """
        Args:
            cache_path: Chemin pour cache JSON des tokens (optionnel)
        """
        self.cache_path = cache_path
        self._usdc_symbols_cache: Optional[Set[str]] = None

    def get_usdc_symbols(self, *, force_refresh: bool = False) -> Set[str]:
        """
        Récupère tous les symboles USDC disponibles sur Binance.

        Args:
            force_refresh: Forcer rafraîchissement du cache

        Returns:
            Set des symboles de base (ex: {'BTC', 'ETH', 'SOL', ...})
        """
        if self._usdc_symbols_cache and not force_refresh:
            return self._usdc_symbols_cache

        url = "https://api.binance.com/api/v3/exchangeInfo"
        try:
            resp = requests.get(url, timeout=10)
            resp.raise_for_status()
            data = resp.json()

            symbols = {
                s["baseAsset"].upper()
                for s in data.get("symbols", [])
                if s["symbol"].endswith("USDC") and s["status"] == "TRADING"
            }

            self._usdc_symbols_cache = symbols
            logger.info(f"✅ Récupéré {len(symbols)} symboles USDC depuis Binance")
            return symbols

        except Exception as e:
            logger.error(f"❌ Erreur get_usdc_symbols: {e}")
            return set()

    def get_top100_marketcap(self) -> List[Dict]:
        """
        Récupère top 100 tokens par capitalisation (CoinGecko).

        Returns:
            Liste de dicts avec: symbol, name, market_cap, market_cap_rank
        """
        url = "https://api.coingecko.com/api/v3/coins/markets"
        params = {
            "vs_currency": "usd",
            "order": "market_cap_desc",
            "per_page": 100,
            "page": 1,
        }

        try:
            resp = requests.get(url, params=params, timeout=10)
            resp.raise_for_status()
            data = resp.json()

            tokens = [
                {
                    "symbol": entry["symbol"].upper(),
                    "name": entry["name"],
                    "market_cap": entry["market_cap"],
                    "market_cap_rank": entry["market_cap_rank"],
                }
                for entry in data
                if isinstance(entry, dict)
            ]

            logger.info(f"✅ Récupéré {len(tokens)} tokens par market cap (CoinGecko)")
            return tokens

        except Exception as e:
            logger.error(f"❌ Erreur get_top100_marketcap: {e}")
            return []

    def get_top100_volume(self) -> List[Dict]:
        """
        Récupère top 100 tokens par volume 24h USDC (Binance).

        Returns:
            Liste de dicts avec: symbol, volume
        """
        url = "https://api.binance.com/api/v3/ticker/24hr"

        try:
            resp = requests.get(url, timeout=10)
            resp.raise_for_status()
            data = resp.json()

            usdc_volumes = [
                {
                    "symbol": entry["symbol"].replace("USDC", "").upper(),
                    "volume": float(entry["quoteVolume"]),
                }
                for entry in data
                if entry["symbol"].endswith("USDC")
            ]

            # Tri par volume décroissant
            usdc_volumes.sort(key=lambda x: x["volume"], reverse=True)
            top100 = usdc_volumes[:100]

            logger.info(f"✅ Récupéré {len(top100)} tokens par volume 24h (Binance)")
            return top100

        except Exception as e:
            logger.error(f"❌ Erreur get_top100_volume: {e}")
            return []

    def merge_and_rank_tokens(
        self,
        marketcap_tokens: List[Dict],
        volume_tokens: List[Dict],
        *,
        save_cache: bool = True,
    ) -> List[Dict]:
        """
        Fusionne tokens par market cap et volume, avec ranking combiné.

        Args:
            marketcap_tokens: Liste tokens CoinGecko
            volume_tokens: Liste tokens Binance volume
            save_cache: Sauvegarder résultat dans cache JSON

        Returns:
            Liste fusionnée triée par (market_cap_rank, -volume)
        """
        merged: Dict[str, Dict] = {}

        # Ajouter tokens market cap
        for mc in marketcap_tokens:
            sym = mc["symbol"].upper()
            merged[sym] = {**mc, "volume": 0}

        # Ajouter/mettre à jour avec volumes
        for v in volume_tokens:
            sym = v["symbol"].upper()
            if sym in merged:
                merged[sym]["volume"] = v["volume"]
            else:
                merged[sym] = {
                    "symbol": sym,
                    "name": sym,
                    "market_cap": None,
                    "market_cap_rank": None,
                    "volume": v["volume"],
                }

        # Charger cache existant et fusionner
        if self.cache_path and self.cache_path.exists():
            try:
                with open(self.cache_path, "r", encoding="utf-8") as f:
                    old_data = json.load(f)
                    old_dict = {
                        i["symbol"].upper(): i
                        for i in old_data
                        if isinstance(i, dict) and "symbol" in i
                    }
                    # Mettre à jour avec nouvelles données
                    old_dict.update(merged)
                    merged = old_dict
            except Exception as e:
                logger.warning(f"⚠️  Impossible de charger cache: {e}")

        # Tri final
        final = sorted(
            merged.values(),
            key=lambda x: (x.get("market_cap_rank") or 999, -x.get("volume", 0)),
        )

        # Sauvegarde cache
        if save_cache and self.cache_path:
            try:
                self.cache_path.parent.mkdir(parents=True, exist_ok=True)
                with open(self.cache_path, "w", encoding="utf-8") as f:
                    json.dump(final, f, indent=2)
                logger.info(
                    f"💾 Cache sauvegardé: {len(final)} tokens → {self.cache_path}"
                )
            except Exception as e:
                logger.error(f"❌ Erreur sauvegarde cache: {e}")

        return final

    def filter_tradeable_usdc(
        self, tokens: List[Dict], *, force_refresh_symbols: bool = False
    ) -> List[str]:
        """
        Filtre tokens pour ne garder que ceux tradables en USDC sur Binance.

        Args:
            tokens: Liste de dicts avec clé 'symbol'
            force_refresh_symbols: Rafraîchir cache symboles Binance

        Returns:
            Liste de symboles USDC (ex: ['BTCUSDC', 'ETHUSDC', ...])
        """
        usdc_symbols = self.get_usdc_symbols(force_refresh=force_refresh_symbols)

        tradeable = [
            f"{token['symbol'].upper()}USDC"
            for token in tokens
            if token.get("symbol", "").upper() in usdc_symbols
        ]

        logger.info(f"🎯 {len(tradeable)}/{len(tokens)} tokens tradables en USDC")
        return tradeable

    def get_top_tokens(
        self, limit: int = 100, *, usdc_only: bool = True, force_refresh: bool = False
    ) -> List[str]:
        """
        Méthode principale: récupère top tokens combinant market cap + volume.

        Args:
            limit: Nombre maximum de tokens
            usdc_only: Ne garder que les paires USDC tradables
            force_refresh: Forcer téléchargement (ignorer cache)

        Returns:
            Liste de symboles (ex: ['BTCUSDC', 'ETHUSDC', ...])
        """
        logger.info(f"🔍 Récupération top {limit} tokens...")

        # Récupération données
        marketcap = self.get_top100_marketcap()
        volume = self.get_top100_volume()

        # Fusion et ranking
        merged = self.merge_and_rank_tokens(
            marketcap, volume, save_cache=not force_refresh
        )

        # Filtrage USDC si demandé
        if usdc_only:
            result = self.filter_tradeable_usdc(merged[:limit])
        else:
            result = [t["symbol"].upper() for t in merged[:limit]]

        logger.info(f"✅ {len(result)} tokens sélectionnés")
        return result[:limit]


# Fonction helper pour compatibilité rétroactive
def get_top100_tokens(cache_path: Optional[Path] = None) -> List[str]:
    """
    Helper: récupère top 100 tokens USDC (compatibilité legacy).

    Args:
        cache_path: Chemin cache JSON optionnel

    Returns:
        Liste symboles USDC tradables
    """
    manager = TokenManager(cache_path=cache_path)
    return manager.get_top_tokens(limit=100, usdc_only=True)


# ============================================================================
# DIVERSITY PROVIDER (fusionné depuis providers/token_diversity.py)
# ============================================================================


@dataclass(frozen=True)
class TokenDiversityConfig:
    """
    Configuration du provider token diversity.

    Attributes:
        groups: Mapping de groupes vers listes de symboles
        symbols: Liste complète de tous les symboles
        supported_tf: Tuple des timeframes supportés
        cache_dir: Répertoire pour le cache des données

    Example:
        >>> config = TokenDiversityConfig(
        ...     groups={"L1": ["BTCUSDC", "ETHUSDC"]},
        ...     symbols=["BTCUSDC", "ETHUSDC"],
        ...     supported_tf=("1h", "4h", "1d"),
        ...     cache_dir="./data/diversity_cache"
        ... )
    """

    groups: Mapping[str, List[str]]
    symbols: List[str]
    supported_tf: Tuple[str, ...] = ("1m", "5m", "15m", "1h", "4h", "1d")
    cache_dir: str = "./data/diversity_cache"

    def __post_init__(self):
        """Valide la configuration après initialisation."""
        # Vérifier que tous les symboles des groupes sont dans symbols
        all_group_symbols = set()
        for group_symbols in self.groups.values():
            all_group_symbols.update(group_symbols)

        missing = all_group_symbols - set(self.symbols)
        if missing:
            logger.warning(f"Symboles dans groupes mais pas dans symbols: {missing}")


class TokenDiversityDataSource:
    """
    Data source pour récupération OHLCV tokens diversifiés (Option B).

    Fournit UNIQUEMENT des données OHLCV brutes. Le calcul des indicateurs
    est délégué à IndicatorBank.

    Attributes:
        config: Configuration du provider

    Example:
        >>> config = create_default_config()
        >>> provider = TokenDiversityDataSource(config)
        >>> symbols = provider.list_symbols("L1")
        >>> df = provider.fetch_ohlcv("BTCUSDC", "1h")
    """

    def __init__(self, config: TokenDiversityConfig):
        """
        Initialise le provider avec une configuration.

        Args:
            config: Configuration TokenDiversityConfig
        """
        self.config = config
        logger.info(
            f"TokenDiversityDataSource initialized: "
            f"{len(config.symbols)} symbols, "
            f"{len(config.groups)} groups"
        )

    def list_symbols(self, group: Optional[str] = None) -> List[str]:
        """
        Liste les symboles disponibles.

        Args:
            group: Nom du groupe (optionnel). Si None, retourne tous les
                symboles

        Returns:
            Liste des symboles

        Example:
            >>> provider.list_symbols("L1")
            ['BTCUSDC', 'ETHUSDC']
            >>> provider.list_symbols()  # Tous les symboles
            ['BTCUSDC', 'ETHUSDC', 'UNIUSDC', ...]
        """
        if group:
            return self.config.groups.get(group, [])
        return self.config.symbols

    def list_groups(self) -> List[str]:
        """
        Liste les groupes disponibles.

        Returns:
            Liste des noms de groupes

        Example:
            >>> provider.list_groups()
            ['L1', 'DeFi', 'L2']
        """
        return list(self.config.groups.keys())

    def fetch_ohlcv(
        self,
        symbol: str,
        timeframe: str,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        limit: int = 1000,
    ) -> pd.DataFrame:
        """
        Récupère les données OHLCV pour un symbole.

        Note: Lecture depuis fichiers locaux (Parquet prioritaire, JSON
        fallback). Utilise IngestionManager pour téléchargement si besoin.

        Args:
            symbol: Symbole à récupérer (ex: "BTCUSDC")
            timeframe: Timeframe (ex: "1h", "4h", "1d")
            start_date: Date de début (optionnel)
            end_date: Date de fin (optionnel)
            limit: Nombre maximum de barres à récupérer

        Returns:
            DataFrame avec colonnes: timestamp, open, high, low, close,
                volume

        Raises:
            ValueError: Si symbole ou timeframe invalide
            FileNotFoundError: Si aucune donnée disponible localement

        Example:
            >>> df = provider.fetch_ohlcv(
            ...     "BTCUSDC",
            ...     "1h",
            ...     start_date=datetime(2025, 1, 1),
            ...     limit=500
            ... )
        """
        # Validation
        if symbol not in self.config.symbols:
            raise ValueError(
                f"Symbole '{symbol}' non supporté. "
                f"Symboles disponibles: {self.config.symbols[:5]}..."
            )

        if timeframe not in self.config.supported_tf:
            raise ValueError(
                f"Timeframe '{timeframe}' non supporté. "
                f"Timeframes supportés: {self.config.supported_tf}"
            )

        # Construction des chemins de fichiers
        # Format: data/crypto_data_parquet/{symbol}_{timeframe}.parquet
        base_dir = Path("./data")
        parquet_dir = base_dir / "crypto_data_parquet"
        json_dir = base_dir / "crypto_data_json"

        filename = f"{symbol}_{timeframe}"
        parquet_file = parquet_dir / f"{filename}.parquet"
        json_file = json_dir / f"{filename}.json"

        df = None

        # Priorité 1: Lecture depuis Parquet (plus rapide)
        if parquet_file.exists():
            try:
                logger.debug(f"Chargement Parquet: {parquet_file}")
                df = pd.read_parquet(parquet_file)

                # Normaliser l'index à UTC si tz-naive
                if isinstance(df.index, pd.DatetimeIndex):
                    if df.index.tz is None:
                        df.index = df.index.tz_localize("UTC")

                logger.debug(f"✅ Parquet chargé: {len(df)} lignes pour {symbol}")
            except Exception as e:
                logger.warning(f"Erreur lecture Parquet {parquet_file}: {e}")

        # Priorité 2: Fallback sur JSON si Parquet échoue
        if df is None and json_file.exists():
            try:
                logger.debug(f"Chargement JSON: {json_file}")
                df_json = pd.read_json(json_file)

                # Conversion timestamp (ms → datetime UTC)
                if "timestamp" in df_json.columns:
                    df_json["timestamp"] = pd.to_datetime(
                        df_json["timestamp"], unit="ms", utc=True
                    )
                    df = df_json.set_index("timestamp").sort_index()
                else:
                    df = df_json

                logger.debug(f"✅ JSON chargé: {len(df)} lignes pour {symbol}")
            except Exception as e:
                logger.warning(f"Erreur lecture JSON {json_file}: {e}")

        # Vérification fichier trouvé
        if df is None:
            raise FileNotFoundError(
                f"Aucune donnée trouvée pour {symbol}_{timeframe}\n"
                f"Fichiers cherchés:\n"
                f"  - {parquet_file}\n"
                f"  - {json_file}\n"
                f"Assurez-vous d'avoir téléchargé les données avec "
                f"scripts/sync_data_smart.py ou IngestionManager"
            )

        # Filtrage par dates
        if start_date is not None:
            # Convertir en pandas Timestamp pour comparaison
            start_ts = pd.Timestamp(start_date)
            df = df[df.index >= start_ts]
            logger.debug(f"Filtré par start_date: {len(df)} lignes")

        if end_date is not None:
            # Convertir en pandas Timestamp pour comparaison
            end_ts = pd.Timestamp(end_date)
            df = df[df.index <= end_ts]
            logger.debug(f"Filtré par end_date: {len(df)} lignes")

        # Application de la limite
        if limit and len(df) > limit:
            df = df.tail(limit)  # Garder les données les plus récentes
            logger.debug(f"Limité à {limit} lignes (plus récentes)")

        # Validation colonnes requises
        required_cols = ["open", "high", "low", "close", "volume"]
        missing_cols = [col for col in required_cols if col not in df.columns]

        if missing_cols:
            raise ValueError(
                f"Colonnes manquantes dans {filename}: {missing_cols}\n"
                f"Colonnes requises: {required_cols}\n"
                f"Colonnes trouvées: {list(df.columns)}"
            )

        # Retour DataFrame propre
        logger.info(
            f"✅ fetch_ohlcv {symbol} {timeframe}: "
            f"{len(df)} lignes ({df.index[0]} → {df.index[-1]})"
        )

        return df[required_cols]

    def validate_symbol(self, symbol: str) -> bool:
        """
        Valide qu'un symbole est supporté.

        Args:
            symbol: Symbole à valider

        Returns:
            True si le symbole est supporté, False sinon

        Example:
            >>> provider.validate_symbol("BTCUSDC")
            True
            >>> provider.validate_symbol("INVALID")
            False
        """
        return symbol in self.config.symbols

    def validate_timeframe(self, timeframe: str) -> bool:
        """
        Valide qu'un timeframe est supporté.

        Args:
            timeframe: Timeframe à valider

        Returns:
            True si le timeframe est supporté, False sinon

        Example:
            >>> provider.validate_timeframe("1h")
            True
            >>> provider.validate_timeframe("7d")
            False
        """
        return timeframe in self.config.supported_tf


def create_default_config() -> TokenDiversityConfig:
    """
    Crée une configuration par défaut avec groupes de démonstration.

    Groupes inclus:
    - L1: Layer 1 blockchains (BTC, ETH, SOL, ADA)
    - DeFi: Protocoles DeFi (UNI, AAVE, LINK, DOT)
    - L2: Layer 2 solutions (MATIC, ARB, OP)
    - Stable: Stablecoins (EUR, FDUSD, USDE)

    Returns:
        TokenDiversityConfig avec configuration par défaut

    Example:
        >>> config = create_default_config()
        >>> provider = TokenDiversityDataSource(config)
        >>> provider.list_groups()
        ['L1', 'DeFi', 'L2', 'Stable']
    """
    default_groups = {
        "L1": [
            "BTCUSDC",
            "ETHUSDC",
            "SOLUSDC",
            "ADAUSDC",
        ],
        "DeFi": [
            "UNIUSDC",
            "AAVEUSDC",
            "LINKUSDC",
            "DOTUSDC",
        ],
        "L2": [
            "MATICUSDC",
            "ARBUSDC",
            "OPUSDC",
        ],
        "Stable": [
            "EURUSDC",
            "FDUSDUSDC",
            "USDEUSDC",
        ],
    }

    # Construire la liste complète des symboles
    all_symbols = []
    for group_symbols in default_groups.values():
        all_symbols.extend(group_symbols)

    # Supprimer doublons
    all_symbols = list(set(all_symbols))

    return TokenDiversityConfig(
        groups=default_groups,
        symbols=all_symbols,
        supported_tf=("1m", "5m", "15m", "1h", "4h", "1d"),
    )


# ---- Compatibilité legacy: façade TokenDiversityManager ----
try:
    TokenDiversityManager  # type: ignore[name-defined]
except NameError:

    class TokenDiversityManager:
        """
        Façade légère pour satisfaire les imports legacy.
        Délègue au moteur actuel (TokenDiversityDataSource).
        """

        def __init__(self, *args, **kwargs):
            # suppose que TokenDiversityDataSource est défini dans ce fichier
            try:
                self._ds = TokenDiversityDataSource(*args, **kwargs)
            except NameError:
                # Si TokenDiversityDataSource est ailleurs, importer localement
                from threadx.data.tokens import TokenDiversityDataSource as _DS

                self._ds = _DS(*args, **kwargs)

        def fetch_ohlcv(self, *a, **k):
            return self._ds.fetch_ohlcv(*a, **k)

        def compute_diversity_metrics(self, *a, **k):
            return getattr(self._ds, "compute_diversity_metrics", lambda *x, **y: None)(
                *a, **k
            )


# Export des classes et fonctions pour la compatibilité des tests
__all__.extend(
    [
        "TokenManager",
        "TokenDiversityDataSource",
        "TokenDiversityManager",
        "IndicatorSpec",
    ]
)
