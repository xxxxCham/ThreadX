"""
ThreadX Data Loader Module - Téléchargement OHLCV unifié
Module consolidé pour téléchargement, cache et conversion de données OHLCV.

Consolide:
- unified_data_historique_with_indicators.py::fetch_klines, download_ohlcv
- src/threadx/data/ingest.py::download_ohlcv_1m
- token_diversity_manager/tradxpro_core_manager_v2.py::download_crypto_data
"""

from __future__ import annotations

import json
import logging
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Dict, Optional, Tuple, Callable
from concurrent.futures import ThreadPoolExecutor, as_completed

import pandas as pd
import requests

logger = logging.getLogger(__name__)


class BinanceDataLoader:
    """Téléchargeur unifié de données OHLCV depuis Binance."""

    # Configuration par défaut
    BINANCE_BASE_URL = "https://api.binance.com/api/v3"
    KLINES_LIMIT = 1000
    TIMEOUT = 10
    RETRY_DELAY = 5

    # Mapping timeframes → millisecondes
    TIMEFRAME_MS = {
        "1m": 60_000,
        "3m": 180_000,
        "5m": 300_000,
        "15m": 900_000,
        "30m": 1_800_000,
        "1h": 3_600_000,
        "3h": 10_800_000,
        "4h": 14_400_000,
        "6h": 21_600_000,
        "12h": 43_200_000,
        "1d": 86_400_000,
    }

    def __init__(
        self,
        json_cache_dir: Optional[Path] = None,
        parquet_cache_dir: Optional[Path] = None,
    ):
        """
        Args:
            json_cache_dir: Répertoire cache JSON (raw data)
            parquet_cache_dir: Répertoire cache Parquet (optimisé)
        """
        self.json_cache_dir = json_cache_dir
        self.parquet_cache_dir = parquet_cache_dir

        if json_cache_dir:
            json_cache_dir.mkdir(parents=True, exist_ok=True)
        if parquet_cache_dir:
            parquet_cache_dir.mkdir(parents=True, exist_ok=True)

    @classmethod
    def timeframe_to_ms(cls, timeframe: str) -> int:
        """Convertit timeframe en millisecondes."""
        return cls.TIMEFRAME_MS.get(timeframe.lower(), 60_000)

    def fetch_klines(
        self,
        symbol: str,
        interval: str,
        start_ms: int,
        end_ms: int,
        *,
        retries: int = 3,
    ) -> List[Dict]:
        """
        Télécharge klines depuis Binance API avec gestion retry.

        Args:
            symbol: Symbole trading (ex: 'BTCUSDC')
            interval: Timeframe (ex: '1m', '1h', '3h')
            start_ms: Timestamp début (millisecondes)
            end_ms: Timestamp fin (millisecondes)
            retries: Nombre tentatives en cas d'erreur

        Returns:
            Liste de dicts avec: timestamp, open, high, low, close, volume, extra
        """
        all_candles: List[Dict] = []
        current_ms = start_ms

        while current_ms < end_ms:
            params = {
                "symbol": symbol,
                "interval": interval,
                "startTime": current_ms,
                "endTime": end_ms,
                "limit": self.KLINES_LIMIT,
            }

            # Retry logic
            for attempt in range(retries):
                try:
                    resp = requests.get(
                        f"{self.BINANCE_BASE_URL}/klines",
                        params=params,
                        timeout=self.TIMEOUT,
                    )
                    resp.raise_for_status()
                    data = resp.json()

                    # Vérifier erreur API
                    if isinstance(data, dict) and "code" in data:
                        raise ValueError(f"Binance API error: {data}")

                    break  # Succès

                except Exception as e:
                    if attempt < retries - 1:
                        logger.warning(
                            f"⚠️  fetch_klines retry {attempt+1}/{retries}: {e}"
                        )
                        time.sleep(self.RETRY_DELAY)
                    else:
                        logger.error(
                            f"❌ fetch_klines failed after {retries} retries: {e}"
                        )
                        return all_candles

            if not data:
                break

            # Conversion format standardisé
            all_candles.extend(
                [
                    {
                        "timestamp": c[0],
                        "open": float(c[1]),
                        "high": float(c[2]),
                        "low": float(c[3]),
                        "close": float(c[4]),
                        "volume": float(c[5]),
                        "extra": {
                            "close_time": c[6],
                            "quote_asset_volume": float(c[7]),
                            "trades_count": int(c[8]),
                            "taker_buy_base_volume": float(c[9]),
                            "taker_buy_quote_volume": float(c[10]),
                        },
                    }
                    for c in data
                ]
            )

            # Avancer au prochain batch
            current_ms = data[-1][0] + 1
            time.sleep(0.2)  # Rate limiting

        logger.info(
            f"📥 Téléchargé {len(all_candles)} klines pour " f"{symbol} {interval}"
        )
        return all_candles

    def download_ohlcv(
        self,
        symbol: str,
        interval: str,
        days_history: int = 365,
        *,
        force_update: bool = False,
        save_json: bool = True,
        save_parquet: bool = True,
    ) -> pd.DataFrame:
        """
        Télécharge OHLCV avec gestion cache intelligente.

        Args:
            symbol: Symbole trading (ex: 'BTCUSDC')
            interval: Timeframe (ex: '1m', '1h')
            days_history: Nombre de jours historiques
            force_update: Forcer téléchargement complet
            save_json: Sauvegarder en JSON
            save_parquet: Sauvegarder en Parquet

        Returns:
            DataFrame avec index DatetimeIndex UTC et colonnes OHLCV
        """
        # Calcul période
        now_ms = int(time.time() * 1000)
        start_ms = now_ms - (days_history * 86_400_000)

        # Chemins cache
        json_path = None
        parquet_path = None

        if self.json_cache_dir:
            json_path = (
                self.json_cache_dir / f"{symbol.upper()}_{interval.lower()}.json"
            )
        if self.parquet_cache_dir:
            parquet_path = (
                self.parquet_cache_dir / f"{symbol.upper()}_{interval.lower()}.parquet"
            )

        # Vérifier cache Parquet (prioritaire)
        if not force_update and save_parquet and parquet_path and parquet_path.exists():
            try:
                df = pd.read_parquet(parquet_path)
                logger.info(f"✅ Chargé depuis cache Parquet: {parquet_path.name}")
                return df
            except Exception as e:
                logger.warning(f"⚠️  Cache Parquet invalide: {e}")

        # Téléchargement données
        candles = self.fetch_klines(symbol, interval, start_ms, now_ms)

        if not candles:
            logger.warning(f"⚠️  Aucune donnée téléchargée pour {symbol} {interval}")
            return pd.DataFrame()

        # Conversion DataFrame
        df = self._candles_to_dataframe(candles)

        # Sauvegarde caches
        if save_json and json_path:
            self._save_json(candles, json_path)

        if save_parquet and parquet_path:
            self._save_parquet(df, parquet_path)

        return df

    def download_multiple(
        self,
        symbols: List[str],
        interval: str,
        days_history: int = 365,
        *,
        max_workers: int = 4,
        progress_callback: Optional[Callable[[float, int, int], None]] = None,
    ) -> Dict[str, pd.DataFrame]:
        """
        Télécharge OHLCV pour plusieurs symboles en parallèle.

        Args:
            symbols: Liste symboles (ex: ['BTCUSDC', 'ETHUSDC'])
            interval: Timeframe commun
            days_history: Jours historiques
            max_workers: Nombre threads parallèles
            progress_callback: Callback progression (pct, done, total)

        Returns:
            Dict {symbol: DataFrame}
        """
        results = {}
        total = len(symbols)
        completed = 0

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {
                executor.submit(
                    self.download_ohlcv, symbol, interval, days_history
                ): symbol
                for symbol in symbols
            }

            for future in as_completed(futures):
                symbol = futures[future]
                try:
                    df = future.result()
                    if not df.empty:
                        results[symbol] = df
                except Exception as e:
                    logger.error(f"❌ Erreur téléchargement {symbol}: {e}")

                completed += 1
                if progress_callback:
                    progress_callback((completed / total) * 100, completed, total)

        logger.info(f"✅ Téléchargé {len(results)}/{total} symboles")
        return results

    def _candles_to_dataframe(self, candles: List[Dict]) -> pd.DataFrame:
        """Convertit liste candles en DataFrame normalisé."""
        df = pd.DataFrame(candles)

        # Index timestamp en UTC
        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
        df = df.set_index("timestamp")

        # Colonnes OHLCV uniquement (supprimer extra)
        ohlcv_cols = ["open", "high", "low", "close", "volume"]
        df = df[ohlcv_cols]

        # Conversion numérique sûre
        for col in ohlcv_cols:
            df[col] = pd.to_numeric(df[col], errors="coerce")

        # Nettoyage
        df = df.dropna()
        df = df.astype("float64")

        # Validation
        if not isinstance(df.index, pd.DatetimeIndex):
            raise ValueError("Index n'est pas DatetimeIndex")
        if df.index.tz is None:
            raise ValueError("Index n'est pas en UTC")

        return df

    def _save_json(self, candles: List[Dict], path: Path) -> None:
        """Sauvegarde candles en JSON."""
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                json.dump(candles, f, indent=2)
            logger.debug(f"💾 JSON sauvegardé: {path.name}")
        except Exception as e:
            logger.error(f"❌ Erreur sauvegarde JSON: {e}")

    def _save_parquet(self, df: pd.DataFrame, path: Path) -> None:
        """Sauvegarde DataFrame en Parquet."""
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            df.to_parquet(path, engine="pyarrow", compression="zstd", index=True)
            logger.debug(f"💾 Parquet sauvegardé: {path.name}")
        except Exception as e:
            logger.error(f"❌ Erreur sauvegarde Parquet: {e}")


# Helper functions pour compatibilité rétroactive
def download_ohlcv(
    symbols: List[str],
    interval: str = "1h",
    days_history: int = 365,
    json_dir: Optional[Path] = None,
    parquet_dir: Optional[Path] = None,
    **kwargs,
) -> Dict[str, pd.DataFrame]:
    """
    Helper function pour compatibilité avec ancien code.

    Args:
        symbols: Liste symboles à télécharger
        interval: Timeframe
        days_history: Nombre jours
        json_dir: Répertoire cache JSON
        parquet_dir: Répertoire cache Parquet

    Returns:
        Dict {symbol: DataFrame}
    """
    loader = BinanceDataLoader(json_cache_dir=json_dir, parquet_cache_dir=parquet_dir)
    return loader.download_multiple(symbols, interval, days_history, **kwargs)
