"""
ThreadX Benchmarks Package
=========================

Outils de benchmark pour ThreadX:
- run_indicators: Benchmark des indicateurs techniques
- run_backtests: Benchmark du moteur de backtest
- utils: Utilitaires de benchmark communs
"""
