# src/threadx/data/udfi_contract.py
"""UDFI contract with DataFrame validation helpers for tests."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Set
import pandas as pd

__all__ = [
    "UDFISpec",
    "UDFIRegistry",
    "register_udfi",
    "get_udfi",
    "list_udfi",
    "assert_udfi",
    "apply_column_map",
    "normalize_dtypes",
    "enforce_index_rules",
    "UDFIError",
    "UDFIIndexError",
    "UDFITypeError",
    "UDFIColumnError",
    "UDFIIntegrityError",
    "REQUIRED_COLS",
    "CRITICAL_COLS",
    "EXPECTED_DTYPES",
]


# ============ Exceptions ============
class UDFIError(Exception):
    pass


class UDFIIndexError(UDFIError):
    pass


class UDFITypeError(UDFIError):
    pass


class UDFIColumnError(UDFIError):
    pass


class UDFIIntegrityError(UDFIError):
    pass


# ============ UDFISpec dataclass ============
@dataclass(frozen=True)
class UDFISpec:
    name: str
    version: str = "1.0"
    params_schema: Optional[Dict[str, Any]] = None
    returns: Optional[Dict[str, Any]] = None


# ============ Registry ============
UDFIRegistry: Dict[str, UDFISpec] = {}


def register_udfi(spec: UDFISpec) -> None:
    UDFIRegistry[spec.name] = spec


def get_udfi(name: str) -> UDFISpec:
    return UDFIRegistry[name]


def list_udfi() -> List[UDFISpec]:
    return list(UDFIRegistry.values())


# ============ DataFrame validation constants ============
REQUIRED_COLS: Set[str] = {"symbol", "open", "high", "low", "close", "volume"}
CRITICAL_COLS: Set[str] = {"open", "high", "low", "close"}
EXPECTED_DTYPES: Dict[str, str] = {
    "open": "float",
    "high": "float",
    "low": "float",
    "close": "float",
    "volume": "float",
}


# ============ Helper functions ============
def apply_column_map(df: pd.DataFrame, mapping: Dict[str, str]) -> pd.DataFrame:
    """Rename columns according to mapping."""
    return df.rename(columns=mapping)


def normalize_dtypes(df: pd.DataFrame) -> pd.DataFrame:
    """Convert numeric columns to proper dtypes."""
    out = df.copy()
    for col in [*CRITICAL_COLS, "volume"]:
        if col in out.columns:
            out[col] = pd.to_numeric(out[col], errors="coerce")
    return out


def enforce_index_rules(df: pd.DataFrame) -> None:
    """Validate index is UTC, sorted, unique."""
    idx = df.index
    if getattr(idx, "tz", None) is None:
        raise UDFIIndexError("Index non-UTC")
    if not idx.is_monotonic_increasing:
        raise UDFIIndexError("Index non trié")
    if idx.has_duplicates:
        raise UDFIIndexError("Index avec doublons")


def assert_udfi(df_or_spec: pd.DataFrame | UDFISpec, *, strict: bool = False) -> None:
    """
    Validate UDFI compliance.
    - If df_or_spec is UDFISpec: validate spec fields
    - If df_or_spec is DataFrame: validate OHLCV schema
    """
    # Handle UDFISpec validation
    if isinstance(df_or_spec, UDFISpec):
        spec = df_or_spec
        if not spec.name or not isinstance(spec.name, str):
            raise ValueError("UDFI name must be a non-empty string")
        if not spec.version or not isinstance(spec.version, str):
            raise ValueError("UDFI version must be a non-empty string")
        if spec.params_schema is not None and not isinstance(spec.params_schema, dict):
            raise TypeError("params_schema must be a dict or None")
        if spec.returns is not None and not isinstance(spec.returns, dict):
            raise TypeError("returns must be a dict or None")
        return

    # Handle DataFrame validation
    df = df_or_spec
    missing = REQUIRED_COLS - set(df.columns)
    if missing:
        raise UDFIColumnError("Colonnes manquantes: %s" % (",".join(sorted(missing)),))

    enforce_index_rules(df)

    for col in CRITICAL_COLS:
        if df[col].isna().any():
            raise UDFIIntegrityError(f"NaN interdits sur {col}")

    if strict:
        if (df["high"] < df["open"]).any():
            raise UDFIIntegrityError("Violation high")

    if strict:
        for col, expected in EXPECTED_DTYPES.items():
            if col in df.columns:
                if not pd.api.types.is_float_dtype(df[col].dtype):
                    raise UDFITypeError(f"Type incorrect pour {col}")
